# RX + DX Combined Chat (`rx_dx_rag_chat.py`)

This script runs a combined Retrieval-Augmented Generation (RAG) chat over both RX and DX chunk indexes.

It does:
- semantic retrieval with FAISS
- lexical overlap re-ranking
- metadata filtering (drug, CPT/ICD/DRG, state/network/cost sections)
- basic conversational follow-up context (for questions like "what is the cost?")
- Azure OpenAI answer generation with source citations

## 1) Requirements

From repo root:

```powershell
pip install -r requirements.txt
```

The script also uses `requests` (usually already available via dependencies). If needed:

```powershell
pip install requests
```

## 2) Required Files

By default, the script expects:

- `rx_index/rx.faiss`
- `rx_index/rx_docs.pkl`
- `dx_index/dx.faiss`
- `dx_index/dx_docs.pkl`

Optional but recommended:

- `rx_index/rx_meta.json`
- `dx_index/dx_meta.json`

`*_meta.json` helps model/dimension compatibility selection.

## 3) Build RX and DX Indexes (if needed)

Use the existing builders in `experiments/`:

```powershell
python .\experiments\rx_faiss_index.py
python .\experiments\dx_faiss_index.py
```

If your input/output paths are different, edit the constants in those files before running.

## 4) Azure OpenAI Settings

Set these in `.env` (repo root) or environment variables:

```env
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com
AZURE_OPENAI_API_VERSION=2025-01-01-preview
AZURE_OPENAI_CHAT_DEPLOYMENT=gpt-4.1
```

Optional overrides:

```env
RX_INDEX_DIR=C:\path\to\rx_index
DX_INDEX_DIR=C:\path\to\dx_index
PREFERRED_EMBED_MODEL=all-MiniLM-L6-v2
```

## 5) Run

From repo root:

```powershell
python .\experiments\rx_dx_rag_chat.py
```

You will see:
- index/model load summary
- detected RX/DX filters
- top sources with scores
- final LLM answer

Type `exit` or `quit` to stop.

## 6) Conversational Follow-Up Behavior

The script tracks in-session context:
- last RX drug(s)
- last DX diagnosis title(s)
- preferred domain (`RX`, `DX`, `BOTH`)

Example:
1. `abraxane cost for breast cancer`
2. `what is teh cost?`

Second query is treated as a follow-up and reuses prior context (including typo-tolerant matching for `"teh"` style mistakes in short cost/price follow-ups).

Note: context is in-memory only and resets when the script restarts.

## 7) Retrieval Details

- FAISS cosine search over embeddings
- score fusion:
  - `0.88 * normalized_vector_score`
  - `0.12 * normalized_lexical_overlap`
- when strict filters return no semantic matches, script falls back to filter-only scan to avoid empty results on contextual follow-ups

## 8) Common Issues

1. `AssertionError` or embedding dimension mismatch
- Cause: query embedding model dim != index dim.
- Fix: rebuild index with intended model, or set `PREFERRED_EMBED_MODEL` correctly.
- Script already tries fallback model selection from index metadata/dimension.

2. Azure `429 RateLimitReached`
- Cause: token/request rate limit.
- Fix: wait and retry. Script includes retry/backoff for 429s.

3. `Missing Azure settings: AZURE_ENDPOINT, AZURE_API_KEY`
- Cause: env vars not set.
- Fix: update `.env` or environment variables.

4. `No matching chunks found.`
- Cause: filters too strict or missing relevant chunks in index.
- Fix: broaden query, check filters printed in console, verify index contains expected drug/diagnosis sections.

5. Hugging Face unauthenticated warning
- Cause: no `HF_TOKEN`.
- Fix: optional. Set `HF_TOKEN` for fewer rate-limit warnings/faster downloads.

## 9) Quick Query Examples

- `feiba fda approved indications`
- `is carvykti and xeloda treat same diseases`
- `how much does CPT code 96416 cost in california`
- `what is the cost of radiation in state of alaska`
- `abraxane cost for breast cancer`
- `what is the cost?`
