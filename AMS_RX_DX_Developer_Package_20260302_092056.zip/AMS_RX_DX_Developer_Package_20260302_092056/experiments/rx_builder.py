import json
import os
import traceback
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


# -----------------------------
# Data container
# -----------------------------
@dataclass
class Doc:
    doc_id: str
    text: str
    meta: Dict[str, Any]


def safe_get(d: Any, path: List[str], default=None):
    """Safely traverse nested dicts."""
    cur = d
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def extract_cost_details_block(cost_details: Any):
    """
    Handles structure like:
      Cost_Details: {
        "AMS_Cost_Projection_ACP": {
          "Description": "...",
          "Patient_Type": {
            "Adult": {"Value": "$4,426", "Yearly_Value": "$225,717"},
            "Pediatric": "Not Indicated"
          }
        },
        ...
      }

    Returns:
      cost_text (string to append into chunk text)
      cost_meta (flattened dict for metadata)
    """
    if not isinstance(cost_details, dict):
        return "", {}

    lines = []
    meta = {}

    for metric, obj in cost_details.items():
        if not isinstance(obj, dict):
            continue

        desc = obj.get("Description", "")
        pt = obj.get("Patient_Type", {}) or {}
        if not isinstance(pt, dict):
            pt = {}

        def pull(v):
            # v may be dict with Value/Yearly_Value, or string "Not Indicated"
            if isinstance(v, dict):
                return v.get("Value", ""), v.get("Yearly_Value", "")
            return (v or ""), ""

        a_val, a_year = pull(pt.get("Adult", ""))
        p_val, p_year = pull(pt.get("Pediatric", ""))

        # text block
        lines.append(f"{metric}: {desc}")
        lines.append(f"  Adult: Value={a_val}  Yearly_Value={a_year}")
        lines.append(f"  Pediatric: Value={p_val}  Yearly_Value={p_year}")

        # flattened meta keys
        norm = metric.upper().replace(" ", "_")
        meta[f"COST_{norm}_ADULT_VALUE"] = str(a_val)
        meta[f"COST_{norm}_ADULT_YEARLY_VALUE"] = str(a_year)
        meta[f"COST_{norm}_PEDIATRIC_VALUE"] = str(p_val)
        meta[f"COST_{norm}_PEDIATRIC_YEARLY_VALUE"] = str(p_year)

    return "\n".join(lines).strip(), meta


def parse_one_rx_json(filepath: str) -> List[Doc]:
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    drug = data.get("Drug", {})
    trade = drug.get("TradeName") or os.path.splitext(os.path.basename(filepath))[0]
    generic = drug.get("GenericName", "")
    category = drug.get("Category", "")
    subcat = drug.get("SubCategory", {}) or {}

    base_meta = {"drug": trade, "source_file": os.path.basename(filepath)}
    docs: List[Doc] = []

    # 1) Overview
    overview_text = (
        f"Drug overview\n"
        f"Trade name: {trade}\n"
        f"Generic name: {generic}\n"
        f"Category: {category}\n"
        f"SubCategory primary: {subcat.get('Primary','')}\n"
        f"SubCategory secondary: {subcat.get('Secondary','')}\n"
        f"Available dosages: {subcat.get('Available Dosages','')}\n"
        f"No. of FDA-approved indications: {drug.get('No_of_FDA_Approved_Indications','')}\n"
    )
    docs.append(Doc(
        doc_id=f"{trade}::overview::{base_meta['source_file']}",
        text=overview_text,
        meta={**base_meta, "chunk_type": "overview"},
    ))

    # 2) HCPCS
    for i, h in enumerate(drug.get("HCPCS", []) or []):
        if not isinstance(h, dict):
            continue
        hcpcs_code = h.get("Code")
        text = (
            f"HCPCS entry for {trade}\n"
            f"Code: {hcpcs_code or ''}\n"
            f"Description: {h.get('Description','')}\n"
            f"Cost: {h.get('Cost',{})}\n"
        )
        docs.append(Doc(
            doc_id=f"{trade}::hcpcs::{hcpcs_code or i}::{base_meta['source_file']}",
            text=text,
            meta={**base_meta, "chunk_type": "hcpcs", "hcpcs_code": hcpcs_code},
        ))

    # 3) NDC
    for i, n in enumerate(drug.get("NDC_SiteOfService", []) or []):
        if not isinstance(n, dict):
            continue
        ndc_code = n.get("NDCCode")
        text = (
            f"NDC entry for {trade}\n"
            f"NDC: {ndc_code or ''}\n"
            f"Package: {n.get('PackageDescription','')}\n"
            f"Strength: {n.get('Strength','')}\n"
            f"Site of service: {n.get('SiteOfService','')}\n"
            f"AWP: {n.get('Average Wholesale Price (AWP)','')}\n"
            f"WAC: {n.get('Wholesale Acquisition Cost (WAC)','')}\n"
            f"NADAC: {n.get('National Average Drug Acquisition Cost (NADAC)','')}\n"
            f"FSS: {n.get('FSS','')}\n"
            f"Rebate: {n.get('Rebate','')}\n"
        )
        docs.append(Doc(
            doc_id=f"{trade}::ndc::{ndc_code or i}::{base_meta['source_file']}",
            text=text,
            meta={**base_meta, "chunk_type": "ndc", "ndc_code": ndc_code},
        ))

    # 4) Indications
    def add_indications(items: Optional[List[Dict[str, Any]]], approval: str):
        for i, item in enumerate(items or []):
            if not isinstance(item, dict):
                continue

            t = item.get("Treatment", {}) or {}
            if not isinstance(t, dict):
                continue

            di = t.get("Dosing_Information", {}) or {}
            if not isinstance(di, dict):
                di = {}

            dur = safe_get(di, ["Duration_of_Drug_Usage", "Patient_Type"], default={}) or {}
            if not isinstance(dur, dict):
                dur = {}

            det = safe_get(di, ["Dosing_Details", "Patient_Type"], default={}) or {}
            if not isinstance(det, dict):
                det = {}

            lot = di.get("Line_of_Therapy", {}) or {}
            if not isinstance(lot, dict):
                lot = {}

            fda_dates = lot.get("FDA_Approved_Date", {}) or {}
            if not isinstance(fda_dates, dict):
                fda_dates = {}

            # Pull cost details from Treatment
            adult_cost_at_dosage = t.get("Adult_Cost_at_Dosage", "")
            ped_cost_at_dosage = t.get("Pediatric_Cost_at_Dosage", "")

            cost_details = t.get("Cost_Details", {}) or {}
            cost_text, cost_meta = extract_cost_details_block(cost_details)

            # Build cost block for chunk text
            cost_lines = []
            if adult_cost_at_dosage:
                cost_lines.append(f"Adult_Cost_at_Dosage: {adult_cost_at_dosage}")
            if ped_cost_at_dosage:
                cost_lines.append(f"Pediatric_Cost_at_Dosage: {ped_cost_at_dosage}")
            if cost_text:
                cost_lines.append(cost_text)
            cost_block = "\n".join(cost_lines).strip()

            text = (
                f"Indication ({approval}) for {trade}\n"
                f"Treatment name: {t.get('Name','')}\n"
                f"Description: {t.get('Treatment_Description','')}\n"
                f"Trigger diagnosis: {lot.get('Trigger_Diagnosis','')}\n"
                f"On-label line of therapy: {lot.get('On_Label_Line_of_Therapy','')}\n"
                f"Unlabeled line of therapy: {lot.get('Unlabeled_Line_of_Therapy','')}\n"
                f"FDA approved date (adult): {fda_dates.get('Adult','')}\n"
                f"FDA approved date (pediatric): {fda_dates.get('Pediatric','')}\n"
                f"Duration adult: {dur.get('Adult','')}\n"
                f"Duration pediatric: {dur.get('Pediatric','')}\n"
                f"Adult dosing: {det.get('Adult_Dosing','')}\n"
                f"Pediatric dosing: {det.get('Pediatric_Dosing','')}\n"
                f"\nCOST DETAILS:\n{cost_block}\n"
            )

            meta = {
                **base_meta,
                "chunk_type": "indication",
                "approval": approval,
                "treatment_name": t.get("Name", ""),
                "cost_meta": cost_meta,
            }
            if adult_cost_at_dosage:
                meta["Adult_Cost_at_Dosage"] = adult_cost_at_dosage
            if ped_cost_at_dosage:
                meta["Pediatric_Cost_at_Dosage"] = ped_cost_at_dosage

            docs.append(Doc(
                doc_id=f"{trade}::indication::{approval}::{i}::{base_meta['source_file']}",
                text=text,
                meta=meta,
            ))

    add_indications(drug.get("FDA_Approved_Indications", []), "fda_approved")
    add_indications(
        drug.get("Non_FDA_Approved", []) or drug.get("Non_FDA_Approved_Indications", []),
        "non_fda_approved",
    )

    return docs


# -----------------------------
# Parse entire folder
# -----------------------------
def parse_rx_folder(folder_path: str) -> List[Doc]:
    all_docs: List[Doc] = []

    for filename in sorted(os.listdir(folder_path)):
        if not filename.lower().endswith(".json"):
            continue

        filepath = os.path.join(folder_path, filename)
        try:
            docs = parse_one_rx_json(filepath)
            all_docs.extend(docs)
            print(f"[OK] Parsed {len(docs)} chunks from {filename}")
        except Exception as e:
            print(f"[FAIL] Failed to parse {filename}: {e}")
            traceback.print_exc()

    return all_docs


# -----------------------------
# Main
# -----------------------------
if __name__ == "__main__":
    # CHANGE THIS to your folder path
    folder_path = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\Input\TestSubset\RX_15"

    docs = parse_rx_folder(folder_path)

    print("\n======================================")
    print(f"TOTAL CHUNKS CREATED: {len(docs)}")
    print("======================================\n")

    # Print first chunks for inspection
    for d in docs[:20]:
        print("DOC_ID:", d.doc_id)
        print("META  :", d.meta)
        print("TEXT  :")
        print(d.text)
        print("-" * 80)
