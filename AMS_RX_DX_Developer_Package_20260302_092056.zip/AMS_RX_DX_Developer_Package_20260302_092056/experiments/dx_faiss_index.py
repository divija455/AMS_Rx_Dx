import json
import os
import pickle
from typing import List, Tuple

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from dx_builder import Doc, parse_dx_folder


def build_faiss_index(
    dx_folder: str,
    out_dir: str = "dx_index",
    embed_model_name: str = "all-MiniLM-L6-v2",
) -> Tuple[str, str]:
    """
    1) Parse all DX JSONs into chunks (Docs)
    2) Embed chunk texts
    3) Build FAISS index (cosine via normalized inner product)
    4) Save index + docs to disk
    """
    os.makedirs(out_dir, exist_ok=True)

    docs: List[Doc] = parse_dx_folder(dx_folder)
    if not docs:
        raise ValueError(f"No DX chunks created from folder: {dx_folder}")

    texts = [d.text for d in docs]

    model = SentenceTransformer(embed_model_name)
    embs = model.encode(texts, normalize_embeddings=True, show_progress_bar=True)
    embs = np.asarray(embs, dtype="float32")

    dim = embs.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embs)

    index_path = os.path.join(out_dir, "dx.faiss")
    docs_path = os.path.join(out_dir, "dx_docs.pkl")
    meta_path = os.path.join(out_dir, "dx_meta.json")

    faiss.write_index(index, index_path)
    with open(docs_path, "wb") as f:
        pickle.dump(docs, f)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "embedding_model": embed_model_name,
                "embedding_dim": int(dim),
                "chunk_count": len(docs),
            },
            f,
            indent=2,
        )

    print("\n[OK] DX index build complete")
    print(f"   Chunks: {len(docs)}")
    print(f"   Embedding dim: {dim}")
    print(f"   Saved index -> {index_path}")
    print(f"   Saved docs  -> {docs_path}")
    print(f"   Saved meta  -> {meta_path}")

    return index_path, docs_path


if __name__ == "__main__":
    DX_FOLDER = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\Input\TestSubset\DX_15"
    OUT_DIR = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\dx_index"
    EMBED_MODEL = "all-MiniLM-L6-v2"

    build_faiss_index(DX_FOLDER, OUT_DIR, EMBED_MODEL)
