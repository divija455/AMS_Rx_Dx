import json
import os
from pathlib import Path
from typing import Dict

import requests

from dx_hybrid_retreival import (
    build_bm25,
    load_artifacts,
    load_compatible_model,
    read_index_meta,
    retrieve_hybrid,
)


def load_dotenv_file(dotenv_path: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    p = Path(dotenv_path)
    if not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def get_config() -> Dict[str, str]:
    root = Path(__file__).resolve().parents[1]
    dot = load_dotenv_file(str(root / ".env"))

    return {
        "INDEX_DIR": os.getenv("DX_INDEX_DIR", str(root / "dx_index")),
        "AZURE_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT", dot.get("AZURE_OPENAI_ENDPOINT", "")),
        "AZURE_API_KEY": os.getenv("AZURE_OPENAI_API_KEY", dot.get("AZURE_OPENAI_API_KEY", "")),
        "AZURE_DEPLOYMENT": os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", dot.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4.1")),
        "AZURE_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION", dot.get("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")),
        "EMBED_MODEL_NAME": os.getenv("DX_EMBED_MODEL", "all-MiniLM-L6-v2"),
    }


SYSTEM_PROMPT = (
    "You are a DX Q&A assistant.\n"
    "Use only the supplied SOURCE blocks to answer.\n"
    "If the answer is not in the sources, reply exactly: Not in the data provided.\n"
    "Be factual. If the diagnosis is ambiguous, say so.\n"
    "When asked about state/network costs, list every matching network row from sources.\n"
    "Do not collapse to ranges or 'most networks' summaries when exhaustive rows are available.\n"
    "Cite claims as [SOURCE n].\n"
)

USER_PROMPT_TEMPLATE = (
    "<question>\n"
    "{question}\n"
    "</question>\n\n"
    "<sources>\n"
    "{sources}\n"
    "</sources>"
)


def azure_chat(cfg: Dict[str, str], messages, temperature: float = 0.1) -> str:
    if not cfg["AZURE_ENDPOINT"] or not cfg["AZURE_API_KEY"]:
        raise RuntimeError("Missing Azure config: AZURE_OPENAI_ENDPOINT and/or AZURE_OPENAI_API_KEY.")

    url = (
        f"{cfg['AZURE_ENDPOINT']}/openai/deployments/{cfg['AZURE_DEPLOYMENT']}"
        f"/chat/completions?api-version={cfg['AZURE_API_VERSION']}"
    )

    headers = {
        "Content-Type": "application/json",
        "api-key": cfg["AZURE_API_KEY"],
    }
    payload = {
        "messages": messages,
        "temperature": temperature,
    }

    r = requests.post(url, headers=headers, data=json.dumps(payload), timeout=90)
    if r.status_code != 200:
        raise RuntimeError(f"Azure call failed ({r.status_code}): {r.text}")
    return r.json()["choices"][0]["message"]["content"]


def build_sources_text(retrieved) -> str:
    blocks = []
    for rank, final_s, bm_s, v_s, doc in retrieved:
        blocks.append(
            f"SOURCE {rank}\n"
            f"doc_id: {doc.doc_id}\n"
            f"section: {doc.meta.get('section','')}\n"
            f"text:\n{doc.text}\n"
        )
    return "\n---\n".join(blocks)


def is_network_cost_query(question: str) -> bool:
    q = question.lower()
    return any(k in q for k in ["network", "state", "allowed"]) and any(
        k in q for k in ["cost", "price", "amount"]
    )


def rag_answer(cfg: Dict[str, str], question: str, retrieved) -> str:
    sources = build_sources_text(retrieved)
    extra = ""
    if is_network_cost_query(question):
        extra = (
            "\n\n<format_requirements>\n"
            "Return one flat bullet per matching network.\n"
            "Each bullet must include: Treatment, State, Network, AllowedFrom, AllowedTo.\n"
            "Do not aggregate multiple networks into ranges.\n"
            "</format_requirements>"
        )
    user = USER_PROMPT_TEMPLATE.format(question=question + extra, sources=sources)
    return azure_chat(
        cfg,
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    )


if __name__ == "__main__":
    cfg = get_config()

    print("Loading DX index...")
    faiss_index, docs, diagnosis_names = load_artifacts(cfg["INDEX_DIR"])
    index_meta = read_index_meta(cfg["INDEX_DIR"])
    embed_model, chosen_model = load_compatible_model(faiss_index, cfg["EMBED_MODEL_NAME"], index_meta)
    bm25 = build_bm25(docs)

    print(
        f"[OK] DX RAG Ready. chunks={len(docs)} dim={faiss_index.d} "
        f"embed_model={chosen_model}\n"
    )

    while True:
        q = input("Ask DX: ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        detailed_mode = is_network_cost_query(q)

        retrieved, filters = retrieve_hybrid(
            query=q,
            embed_model=embed_model,
            faiss_index=faiss_index,
            bm25=bm25,
            docs=docs,
            diagnosis_names=diagnosis_names,
            top_k=20 if detailed_mode else 8,
            bm25_k=200 if detailed_mode else 80,
            vec_k=200 if detailed_mode else 80,
            alpha=0.55,
        )

        print(f"\nDetected filters: {filters}\n")
        for rank, final_s, bm_s, v_s, doc in retrieved[:5]:
            print(f"SOURCE {rank}: {doc.doc_id} (score={final_s:.3f})")

        print("\n--- GENERATED ANSWER ---\n")
        answer = rag_answer(cfg, q, retrieved)
        print(answer)
        print("\n" + "=" * 80 + "\n")
