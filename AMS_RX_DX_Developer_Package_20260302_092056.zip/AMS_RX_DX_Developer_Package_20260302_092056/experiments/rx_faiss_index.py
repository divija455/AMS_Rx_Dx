import os
import pickle
from typing import List, Tuple

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

# Import your Step 1 code (recommended)
# Option A: put step1_parse_rx_folder.py in same folder and import parse_rx_folder + Doc
from rx_builder import parse_rx_folder, Doc


def build_faiss_index(
    rx_folder: str,
    out_dir: str = "rx_index",
    embed_model_name: str = "BAAI/bge-base-en-v1.5",
) -> Tuple[str, str]:
    """
    1) Parse all JSONs into chunks (Docs)
    2) Embed chunk texts using open-source embeddings
    3) Build FAISS index (cosine via normalized inner product)
    4) Save index + docs to disk
    """
    os.makedirs(out_dir, exist_ok=True)

    # 1) Parse
    docs: List[Doc] = parse_rx_folder(rx_folder)
    if not docs:
        raise ValueError(f"No chunks created from folder: {rx_folder}")

    texts = [d.text for d in docs]

    # 2) Embed
    model = SentenceTransformer(embed_model_name)
    embs = model.encode(texts, normalize_embeddings=True, show_progress_bar=True)
    embs = np.asarray(embs, dtype="float32")

    # 3) Build FAISS index
    dim = embs.shape[1]
    index = faiss.IndexFlatIP(dim)  # cosine similarity because vectors are normalized
    index.add(embs)

    # 4) Save artifacts
    index_path = os.path.join(out_dir, "rx.faiss")
    docs_path = os.path.join(out_dir, "rx_docs.pkl")

    faiss.write_index(index, index_path)
    with open(docs_path, "wb") as f:
        pickle.dump(docs, f)

    print("\n✅ Index build complete")
    print(f"   Chunks: {len(docs)}")
    print(f"   Embedding dim: {dim}")
    print(f"   Saved index -> {index_path}")
    print(f"   Saved docs  -> {docs_path}")

    return index_path, docs_path


if __name__ == "__main__":
    # 🔵 CHANGE THIS to your folder of 15 JSONs
    RX_FOLDER = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\Input\TestSubset\RX_15"

    # Optional: change where index is saved
    OUT_DIR = "rx_index"

    # Optional: you can swap to other OSS models:
    # - "intfloat/e5-large-v2"
    # - "BAAI/bge-m3"
    EMBED_MODEL = "BAAI/bge-base-en-v1.5"

    build_faiss_index(RX_FOLDER, OUT_DIR, EMBED_MODEL)