import json
import requests
from sentence_transformers import SentenceTransformer

# Import your hybrid retrieval functions
from rx_hybrid_retreival import load_artifacts, build_bm25, retrieve_hybrid


# ==============================
# 🔵 HARD-CODED CONFIG
# ==============================

INDEX_DIR = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\rx_index"

AZURE_ENDPOINT = "https://nlplogix-openai.openai.azure.com"
AZURE_API_KEY = "bbade8a1e4f34798965f259332d08f11"
AZURE_DEPLOYMENT = "gpt-4.1"
AZURE_API_VERSION = "2025-01-01-preview"

EMBED_MODEL_NAME = "BAAI/bge-base-en-v1.5"

SYSTEM_PROMPT = (
    "You are an Rx Q&A assistant.\n"
    "Use only the supplied SOURCE blocks to answer.\n"
    "If the answer is not in the sources, reply exactly: Not in the data provided.\n"
    "Do not paste source text verbatim.\n"
    "Keep the answer concise and factual.\n"
    "Cite claims as [SOURCE n].\n"
)

USER_PROMPT_TEMPLATE = (
    "<question>\n"
    "{question}\n"
    "</question>\n\n"
    "<sources>\n"
    "{sources}\n"
    "</sources>"
)


# ==============================
# Azure Chat Call
# ==============================

def azure_chat(messages, temperature=0.2):
    url = f"{AZURE_ENDPOINT}/openai/deployments/{AZURE_DEPLOYMENT}/chat/completions?api-version={AZURE_API_VERSION}"

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY,
    }

    payload = {
        "messages": messages,
        "temperature": temperature,
    }

    r = requests.post(url, headers=headers, data=json.dumps(payload), timeout=60)

    if r.status_code != 200:
        raise RuntimeError(f"Azure call failed ({r.status_code}): {r.text}")

    return r.json()["choices"][0]["message"]["content"]


# ==============================
# Build context for LLM
# ==============================

def build_sources_text(retrieved):
    blocks = []
    for rank, final_s, bm_s, v_s, doc in retrieved:
        blocks.append(
            f"SOURCE {rank}\n"
            f"doc_id: {doc.doc_id}\n"
            f"text:\n{doc.text}\n"
        )
    return "\n---\n".join(blocks)


def rag_answer(question, retrieved):
    sources = build_sources_text(retrieved)
    user = USER_PROMPT_TEMPLATE.format(question=question, sources=sources)

    return azure_chat([
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ])


# ==============================
# Main
# ==============================

if __name__ == "__main__":

    print("Loading index...")
    faiss_index, docs, drug_names = load_artifacts(INDEX_DIR)
    bm25 = build_bm25(docs)
    embed_model = SentenceTransformer(EMBED_MODEL_NAME)

    print("✅ RAG Ready. Ask a question (or type exit).\n")

    while True:
        q = input("> ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        # Retrieval
        retrieved, filters = retrieve_hybrid(
            query=q,
            embed_model=embed_model,
            faiss_index=faiss_index,
            bm25=bm25,
            docs=docs,
            drug_names=drug_names,
            top_k=8,
            bm25_k=60,
            vec_k=60,
            alpha=0.55,
        )

        print(f"\nDetected filters: {filters}\n")

        for rank, final_s, bm_s, v_s, doc in retrieved[:5]:
            print(f"SOURCE {rank}: {doc.doc_id} (score={final_s:.3f})")

        print("\n--- GENERATED ANSWER ---\n")

        answer = rag_answer(q, retrieved)
        print(answer)

        print("\n" + "=" * 80 + "\n")
