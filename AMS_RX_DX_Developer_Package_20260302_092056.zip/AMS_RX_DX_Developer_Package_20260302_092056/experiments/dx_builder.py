import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List


# Reuse the existing DX chunking logic from Input/src.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DX_SRC_DIR = PROJECT_ROOT / "Input" / "src"
if str(DX_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(DX_SRC_DIR))

from dx_chunk_builder import build_dx_chunks, detect_entity  # noqa: E402


@dataclass
class Doc:
    doc_id: str
    text: str
    meta: Dict[str, Any]


def parse_one_dx_json(filepath: str) -> List[Doc]:
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    filename = os.path.basename(filepath)
    stem = os.path.splitext(filename)[0]
    entity = detect_entity(data, stem)
    if not entity:
        return []

    entity_type, payload, title = entity
    if entity_type not in {"Diagnosis", "DiagnosisDescription", "DiagnosisCost"}:
        return []

    base_meta = {
        "entity_type": "Diagnosis",
        "doc_title": title,
        "source_file": filename,
    }

    chunk_dicts = build_dx_chunks(payload, base_meta)
    docs: List[Doc] = []

    for i, chunk in enumerate(chunk_dicts):
        section = str(chunk.get("section", "DX.UNKNOWN"))
        batch = chunk.get("batch")
        meta = {
            **base_meta,
            "chunk_type": "dx",
            "section": section,
        }
        if batch is not None:
            meta["batch"] = str(batch)

        docs.append(
            Doc(
                doc_id=f"{title}::{section}::{i}::{filename}",
                text=str(chunk.get("text", "")),
                meta=meta,
            )
        )

    return docs


def parse_dx_folder(folder_path: str) -> List[Doc]:
    all_docs: List[Doc] = []

    for filename in sorted(os.listdir(folder_path)):
        if not filename.lower().endswith(".json"):
            continue

        filepath = os.path.join(folder_path, filename)
        try:
            docs = parse_one_dx_json(filepath)
            all_docs.extend(docs)
            print(f"[OK] Parsed {len(docs)} chunks from {filename}")
        except Exception as e:
            print(f"[FAIL] Failed to parse {filename}: {e}")

    return all_docs


if __name__ == "__main__":
    folder_path = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\Input\TestSubset\DX_15"

    docs = parse_dx_folder(folder_path)

    print("\n======================================")
    print(f"TOTAL DX CHUNKS CREATED: {len(docs)}")
    print("======================================\n")

    for d in docs[:20]:
        print("DOC_ID:", d.doc_id)
        print("META  :", d.meta)
        print("TEXT  :")
        print(d.text)
        print("-" * 80)
