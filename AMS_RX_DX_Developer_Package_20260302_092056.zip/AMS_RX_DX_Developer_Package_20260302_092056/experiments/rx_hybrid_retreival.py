import os
import re
import pickle
from typing import List, Tuple, Dict, Any

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi

from rx_builder import Doc


def load_artifacts(index_dir: str) -> Tuple[faiss.Index, List[Doc], List[str]]:
    index_path = os.path.join(index_dir, "rx.faiss")
    docs_path = os.path.join(index_dir, "rx_docs.pkl")

    index = faiss.read_index(index_path)
    with open(docs_path, "rb") as f:
        docs = pickle.load(f)

    drug_names = sorted(set(d.meta.get("drug", "") for d in docs if d.meta.get("drug")))
    return index, docs, drug_names


def tokenize(text: str) -> List[str]:
    # simple tokenizer: lowercase words + keep codes with dashes
    return re.findall(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", text.lower())


def build_bm25(docs: List[Doc]) -> BM25Okapi:
    corpus_tokens = [tokenize(d.text) for d in docs]
    return BM25Okapi(corpus_tokens)


def detect_filters(query: str, drug_names: List[str]) -> Dict[str, Any]:
    q = query.strip().lower()
    filters: Dict[str, Any] = {}

    if "ndc" in q:
        filters["chunk_type"] = "ndc"
    elif "hcpcs" in q:
        filters["chunk_type"] = "hcpcs"
    elif any(
        k in q
        for k in [
            "indication",
            "dosing",
            "line of therapy",
            "treat",
            "treats",
            "treatment",
            "disease",
            "diagnosis",
            "cancer",
        ]
    ):
        filters["chunk_type"] = "indication"

    if any(k in q for k in ["non fda", "non-fda", "off label", "off-label"]):
        filters["approval"] = "non_fda_approved"
    elif "fda" in q:
        filters["approval"] = "fda_approved"

    # exact substring drug match
    matches = sorted({dn for dn in drug_names if dn.lower() in q}, key=len, reverse=True)
    if len(matches) == 1:
        filters["drug"] = matches[0]
    elif len(matches) > 1:
        # Comparison queries can mention multiple drugs (e.g., "A and B").
        filters["drug_any"] = matches

    # exact code filters (optional)
    ndc = re.search(r"\b(\d{4,5}-\d{3,4}-\d{1,2}|\d{10,11})\b", query)
    if ndc:
        filters["ndc_code"] = ndc.group(1)

    hcpcs = re.search(r"\b([A-Z]\d{4})\b", query.upper())
    if hcpcs:
        filters["hcpcs_code"] = hcpcs.group(1)

    return filters


def meta_matches(doc: Doc, filters: Dict[str, Any]) -> bool:
    for k, v in filters.items():
        if k == "drug_any":
            if doc.meta.get("drug") not in v:
                return False
        elif doc.meta.get(k) != v:
            return False
    return True


def retrieve_hybrid(
    query: str,
    embed_model: SentenceTransformer,
    faiss_index: faiss.Index,
    bm25: BM25Okapi,
    docs: List[Doc],
    drug_names: List[str],
    top_k: int = 8,
    bm25_k: int = 60,
    vec_k: int = 60,
    alpha: float = 0.5,
):
    """
    alpha controls mixing:
      final_score = alpha * bm25_norm + (1-alpha) * vec_norm
    """
    filters = detect_filters(query, drug_names)

    # --- BM25 retrieval ---
    q_tokens = tokenize(query)
    bm25_scores = bm25.get_scores(q_tokens)  # array length = len(docs)
    bm25_top = np.argsort(bm25_scores)[::-1][:bm25_k]

    # --- Vector retrieval ---
    q_emb = embed_model.encode([query], normalize_embeddings=True).astype("float32")
    vec_scores, vec_idxs = faiss_index.search(q_emb, vec_k)
    vec_idxs = vec_idxs[0]
    vec_scores = vec_scores[0]

    # --- Combine candidates ---
    candidates = set(int(i) for i in bm25_top) | set(int(i) for i in vec_idxs)

    # normalize scores to 0..1 within candidate set
    bm_vals = np.array([bm25_scores[i] for i in candidates], dtype=float)
    v_map = {int(vec_idxs[i]): float(vec_scores[i]) for i in range(len(vec_idxs))}
    v_vals = np.array([v_map.get(i, 0.0) for i in candidates], dtype=float)

    def norm(arr):
        if arr.size == 0:
            return arr
        mn, mx = float(arr.min()), float(arr.max())
        if mx - mn < 1e-9:
            return np.zeros_like(arr)
        return (arr - mn) / (mx - mn)

    bm_n = norm(bm_vals)
    v_n = norm(v_vals)

    # score + filter
    scored = []
    cand_list = list(candidates)
    for j, idx in enumerate(cand_list):
        doc = docs[idx]
        if filters and not meta_matches(doc, filters):
            continue
        final_score = alpha * bm_n[j] + (1 - alpha) * v_n[j]
        scored.append((final_score, idx, bm25_scores[idx], v_map.get(idx, 0.0)))

    scored.sort(reverse=True, key=lambda x: x[0])
    top = scored[:top_k]

    results = []
    for rank, (final_s, idx, bm_s, v_s) in enumerate(top, start=1):
        results.append((rank, final_s, bm_s, v_s, docs[idx]))

    return results, filters


if __name__ == "__main__":
    INDEX_DIR = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\rx_index"
    EMBED_MODEL_NAME = "BAAI/bge-base-en-v1.5"

    faiss_index, docs, drug_names = load_artifacts(INDEX_DIR)
    embed_model = SentenceTransformer(EMBED_MODEL_NAME)
    bm25 = build_bm25(docs)

    print(f"Loaded {len(docs)} chunks, {len(drug_names)} drugs. Hybrid retrieval ready.\n")

    while True:
        q = input("Ask ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        results, filters = retrieve_hybrid(
            q, embed_model, faiss_index, bm25, docs, drug_names,
            top_k=8, bm25_k=60, vec_k=60, alpha=0.55
        )

        print(f"\nDetected filters: {filters}\n")
        for rank, final_s, bm_s, v_s, doc in results:
            print(f"#{rank} final={final_s:.4f}  bm25={bm_s:.2f}  vec={v_s:.4f}")
            print("doc_id:", doc.doc_id)
            print("meta  :", doc.meta)
            print("text  :")
            print(doc.text[:650])
            print("-" * 80)
        print("\n" + "=" * 80 + "\n")
