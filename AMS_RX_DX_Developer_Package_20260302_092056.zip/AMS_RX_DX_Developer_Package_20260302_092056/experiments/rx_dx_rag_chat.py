import json
import os
import pickle
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import faiss
import numpy as np
import requests
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = Path(__file__).resolve().parents[1]
EXPERIMENTS_DIR = PROJECT_ROOT / "experiments"
DX_SRC_DIR = PROJECT_ROOT / "Input" / "src"
for p in [str(EXPERIMENTS_DIR), str(DX_SRC_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

# Required so pickle can resolve Doc classes.
import dx_builder  # noqa: F401,E402
import rx_builder  # noqa: F401,E402


MODEL_BY_DIM = {
    384: "all-MiniLM-L6-v2",
    768: "BAAI/bge-base-en-v1.5",
}

STATE_NAMES = [
    "Alabama",
    "Alaska",
    "Arizona",
    "Arkansas",
    "California",
    "Colorado",
    "Connecticut",
    "Delaware",
    "Florida",
    "Georgia",
    "Hawaii",
    "Idaho",
    "Illinois",
    "Indiana",
    "Iowa",
    "Kansas",
    "Kentucky",
    "Louisiana",
    "Maine",
    "Maryland",
    "Massachusetts",
    "Michigan",
    "Minnesota",
    "Mississippi",
    "Missouri",
    "Montana",
    "Nebraska",
    "Nevada",
    "New Hampshire",
    "New Jersey",
    "New Mexico",
    "New York",
    "North Carolina",
    "North Dakota",
    "Ohio",
    "Oklahoma",
    "Oregon",
    "Pennsylvania",
    "Rhode Island",
    "South Carolina",
    "South Dakota",
    "Tennessee",
    "Texas",
    "Utah",
    "Vermont",
    "Virginia",
    "Washington",
    "West Virginia",
    "Wisconsin",
    "Wyoming",
    "District of Columbia",
]


@dataclass
class Hit:
    source_type: str  # "RX" | "DX"
    score: float
    vec_score: float
    lex_score: float
    doc: Any


@dataclass
class SessionContext:
    last_rx_drugs: List[str]
    last_dx_titles: List[str]
    preferred_domain: str  # "RX" | "DX" | "BOTH"


def load_dotenv_file(path: Path) -> Dict[str, str]:
    if not path.exists():
        return {}
    out: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def read_index_meta(index_dir: str, prefix: str) -> Dict[str, Any]:
    meta_path = os.path.join(index_dir, f"{prefix}_meta.json")
    if not os.path.exists(meta_path):
        return {}
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_compatible_model(index: faiss.Index, preferred: str, meta: Dict[str, Any]) -> Tuple[SentenceTransformer, str]:
    candidates: List[str] = []
    for name in [preferred, str(meta.get("embedding_model", "")), MODEL_BY_DIM.get(index.d, "")]:
        if name and name not in candidates:
            candidates.append(name)

    for model_name in candidates:
        model = SentenceTransformer(model_name)
        probe = np.asarray(model.encode(["dimension-check"], normalize_embeddings=True), dtype="float32")
        if probe.shape[1] == index.d:
            return model, model_name

    raise RuntimeError(
        f"No compatible embedding model for dim={index.d}. Tried: {candidates}. "
        "Rebuild the index with a known model."
    )


def load_index_bundle(index_dir: str, prefix: str, preferred_model: str) -> Tuple[faiss.Index, List[Any], SentenceTransformer, str]:
    index_path = os.path.join(index_dir, f"{prefix}.faiss")
    docs_path = os.path.join(index_dir, f"{prefix}_docs.pkl")
    if not os.path.exists(index_path) or not os.path.exists(docs_path):
        raise FileNotFoundError(f"Missing index artifacts: {index_path} or {docs_path}")

    index = faiss.read_index(index_path)
    with open(docs_path, "rb") as f:
        docs = pickle.load(f)

    meta = read_index_meta(index_dir, prefix)
    model, model_name = load_compatible_model(index, preferred_model, meta)
    return index, docs, model, model_name


def tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", (text or "").lower())


def lexical_overlap(query_tokens: List[str], text_tokens: List[str]) -> float:
    if not query_tokens or not text_tokens:
        return 0.0
    q = set(query_tokens)
    t = set(text_tokens)
    return float(len(q & t)) / float(len(q))


def normalize_scores(vals: List[float]) -> List[float]:
    if not vals:
        return []
    mn = min(vals)
    mx = max(vals)
    if abs(mx - mn) < 1e-9:
        return [0.0 for _ in vals]
    return [(v - mn) / (mx - mn) for v in vals]


def detect_state(query: str) -> Optional[str]:
    q = query.lower()
    for state in sorted(STATE_NAMES, key=len, reverse=True):
        if re.search(rf"\b{re.escape(state.lower())}\b", q):
            return state
    return None


def detect_rx_filters(query: str, drug_names: List[str]) -> Dict[str, Any]:
    q = query.strip().lower()
    filters: Dict[str, Any] = {}

    if "ndc" in q:
        filters["chunk_type"] = "ndc"
    elif "hcpcs" in q:
        filters["chunk_type"] = "hcpcs"
    elif any(k in q for k in ["indication", "dosing", "line of therapy", "treat", "treatment", "fda"]):
        filters["chunk_type"] = "indication"

    if any(k in q for k in ["non fda", "non-fda", "off label", "off-label"]):
        filters["approval"] = "non_fda_approved"
    elif "fda" in q:
        filters["approval"] = "fda_approved"

    matches = sorted({dn for dn in drug_names if dn.lower() in q}, key=len, reverse=True)
    if len(matches) == 1:
        filters["drug"] = matches[0]
    elif len(matches) > 1:
        filters["drug_any"] = matches

    ndc = re.search(r"\b(\d{4,5}-\d{3,4}-\d{1,2}|\d{10,11})\b", query)
    if ndc:
        filters["ndc_code"] = ndc.group(1)

    hcpcs = re.search(r"\b([A-Z]\d{4})\b", query.upper())
    if hcpcs:
        filters["hcpcs_code"] = hcpcs.group(1)

    return filters


def detect_dx_filters(query: str, diagnosis_names: List[str]) -> Dict[str, Any]:
    q = query.strip().lower()
    filters: Dict[str, Any] = {}

    if any(k in q for k in ["icd10", "icd-10", "icd 10", "icd code", "icd codes"]):
        filters["section_prefix"] = "DX.CodingReferences.ICD10"
    elif "drg" in q:
        filters["section_prefix"] = "DX.CodingReferences.DRG"
    elif "cpt" in q:
        filters["section_prefix"] = "DX.CodingReferences.CPT"
    elif any(k in q for k in ["state", "network", "medicare", "cost", "price", "allowed"]):
        filters["section_prefix"] = "DX.TreatmentAnalytics"
    elif "complication" in q:
        filters["section_prefix"] = "DX.Complications"
    elif "description" in q:
        filters["section_prefix"] = "DX.Description"
    elif any(k in q for k in ["physician comments", "clinical notes"]):
        filters["section_prefix"] = "DX.PhysicianComments"

    matches = sorted({dn for dn in diagnosis_names if dn.lower() in q}, key=len, reverse=True)
    if len(matches) == 1:
        filters["doc_title"] = matches[0]
    elif len(matches) > 1:
        filters["doc_title_any"] = matches

    code_match = re.search(r"\b([A-TV-Z][0-9][0-9A-Z](?:\.[0-9A-Z]{1,4})?)\b", query.upper())
    if code_match:
        filters["text_contains"] = code_match.group(1)

    cpt_match = re.search(r"\b(\d{5})\b", query)
    if cpt_match and filters.get("section_prefix", "").startswith("DX.CodingReferences.CPT"):
        filters["text_contains"] = cpt_match.group(1)

    drg_match = re.search(r"\b(\d{3})\b", query)
    if drg_match and filters.get("section_prefix", "").startswith("DX.CodingReferences.DRG"):
        filters["text_contains"] = drg_match.group(1)

    state = detect_state(query)
    if state and filters.get("section_prefix", "").startswith("DX.TreatmentAnalytics"):
        filters["text_contains_state"] = f"State={state}"

    return filters


def rx_meta_matches(doc: Any, filters: Dict[str, Any]) -> bool:
    meta = getattr(doc, "meta", {}) or {}
    for k, v in filters.items():
        if k == "drug_any":
            if meta.get("drug") not in v:
                return False
        elif meta.get(k) != v:
            return False
    return True


def dx_meta_matches(doc: Any, filters: Dict[str, Any]) -> bool:
    meta = getattr(doc, "meta", {}) or {}
    text = getattr(doc, "text", "")
    for k, v in filters.items():
        if k == "section_prefix":
            section = str(meta.get("section", ""))
            if not section.startswith(v):
                return False
        elif k == "doc_title_any":
            if meta.get("doc_title") not in v:
                return False
        elif k == "text_contains":
            if str(v).lower() not in text.lower():
                return False
        elif k == "text_contains_state":
            if str(v) not in text:
                return False
        elif meta.get(k) != v:
            return False
    return True


def retrieve_from_index(
    query: str,
    source_type: str,
    index: faiss.Index,
    docs: List[Any],
    model: SentenceTransformer,
    top_n: int,
    filters: Dict[str, Any],
    match_fn,
    relax_filters_if_empty: bool = False,
) -> List[Hit]:
    q_emb = np.asarray(model.encode([query], normalize_embeddings=True), dtype="float32")
    if q_emb.shape[1] != index.d:
        raise ValueError(
            f"{source_type} embedding mismatch: query dim={q_emb.shape[1]} index dim={index.d}"
        )

    k = min(max(top_n, 1), max(len(docs), 1))
    vec_scores, vec_idxs = index.search(q_emb, k)

    q_tokens = tokenize(query)
    vec_rows: List[Tuple[float, int, float]] = []
    for i in range(len(vec_idxs[0])):
        idx = int(vec_idxs[0][i])
        if idx < 0 or idx >= len(docs):
            continue
        doc = docs[idx]
        if filters and not match_fn(doc, filters):
            continue
        vec_score = float(vec_scores[0][i])
        lex_score = lexical_overlap(q_tokens, tokenize(getattr(doc, "text", "")))
        vec_rows.append((vec_score, idx, lex_score))

    if not vec_rows and filters and relax_filters_if_empty:
        for i in range(min(50, len(vec_idxs[0]))):
            idx = int(vec_idxs[0][i])
            if idx < 0 or idx >= len(docs):
                continue
            doc = docs[idx]
            vec_score = float(vec_scores[0][i])
            lex_score = lexical_overlap(q_tokens, tokenize(getattr(doc, "text", "")))
            vec_rows.append((vec_score, idx, lex_score))

    # If filters are explicit but semantic shortlist is empty, fall back to filter-only scan.
    if not vec_rows and filters:
        for idx, doc in enumerate(docs):
            if not match_fn(doc, filters):
                continue
            vec_score = 0.0
            lex_score = lexical_overlap(q_tokens, tokenize(getattr(doc, "text", "")))
            vec_rows.append((vec_score, idx, lex_score))
            if len(vec_rows) >= 50:
                break

    if not vec_rows:
        return []

    vec_norm = normalize_scores([r[0] for r in vec_rows])
    lex_norm = normalize_scores([r[2] for r in vec_rows])

    hits: List[Hit] = []
    for j, (_, idx, _) in enumerate(vec_rows):
        final = 0.88 * vec_norm[j] + 0.12 * lex_norm[j]
        hits.append(
            Hit(
                source_type=source_type,
                score=final,
                vec_score=vec_norm[j],
                lex_score=lex_norm[j],
                doc=docs[idx],
            )
        )
    hits.sort(key=lambda h: h.score, reverse=True)
    return hits


def looks_rx_query(query: str, rx_drug_names: List[str]) -> bool:
    q = query.lower()
    if any(d.lower() in q for d in rx_drug_names):
        return True
    return any(k in q for k in ["drug", "ndc", "hcpcs", "fda", "indication", "dosing", "trade name", "generic"])


def looks_dx_query(query: str, dx_names: List[str]) -> bool:
    q = query.lower()
    if any(d.lower() in q for d in dx_names):
        return True
    return any(k in q for k in ["diagnosis", "icd", "cpt", "drg", "state", "network", "medicare", "complication"])


def is_followup_query(query: str) -> bool:
    q = query.strip().lower()
    followup_patterns = [
        "what is the cost",
        "what's the cost",
        "what is the price",
        "what's the price",
        "how much is it",
        "how much does it cost",
        "and the cost",
        "and what about cost",
    ]
    if any(p in q for p in followup_patterns):
        return True
    # Tolerate small typos like "what is teh cost".
    if re.search(r"\bwhat\s+is\s+\w+\s+(cost|price)\b", q):
        return True
    # Very short question with pronoun is usually contextual follow-up.
    toks = tokenize(q)
    if len(toks) <= 7 and any(p in toks for p in ["it", "that", "those", "them"]):
        return True
    # Short "what/how much cost" forms are usually follow-up in chat.
    if (
        len(toks) <= 7
        and any(k in toks for k in ["cost", "price"])
        and any(w in toks for w in ["what", "how", "much"])
    ):
        return True
    return False


def apply_context_if_needed(
    query: str,
    rx_filters: Dict[str, Any],
    dx_filters: Dict[str, Any],
    wants_rx: bool,
    wants_dx: bool,
    ctx: SessionContext,
) -> Tuple[Dict[str, Any], Dict[str, Any], bool, bool]:
    if not is_followup_query(query):
        return rx_filters, dx_filters, wants_rx, wants_dx

    rx_filters = dict(rx_filters)
    dx_filters = dict(dx_filters)

    has_explicit_rx = ("drug" in rx_filters) or ("drug_any" in rx_filters)
    has_explicit_dx = ("doc_title" in dx_filters) or ("doc_title_any" in dx_filters)

    if not has_explicit_rx and ctx.last_rx_drugs:
        if len(ctx.last_rx_drugs) == 1:
            rx_filters["drug"] = ctx.last_rx_drugs[0]
        else:
            rx_filters["drug_any"] = ctx.last_rx_drugs[:3]

    if not has_explicit_dx and ctx.last_dx_titles:
        if len(ctx.last_dx_titles) == 1:
            dx_filters["doc_title"] = ctx.last_dx_titles[0]
        else:
            dx_filters["doc_title_any"] = ctx.last_dx_titles[:3]

    if not wants_rx and not wants_dx:
        if ctx.preferred_domain == "RX":
            wants_rx, wants_dx = True, False
        elif ctx.preferred_domain == "DX":
            wants_rx, wants_dx = False, True
        else:
            wants_rx, wants_dx = True, True
    elif not has_explicit_rx and not has_explicit_dx and is_followup_query(query):
        # If follow-up is vague and we have prior drug context, bias to RX.
        if ctx.last_rx_drugs and not ctx.last_dx_titles:
            wants_rx, wants_dx = True, False
        elif ctx.last_rx_drugs and ctx.last_dx_titles and ctx.preferred_domain == "BOTH":
            wants_rx, wants_dx = True, False
    elif ctx.preferred_domain == "RX" and not has_explicit_dx and is_followup_query(query):
        wants_rx, wants_dx = True, False
    elif ctx.preferred_domain == "DX" and not has_explicit_rx and is_followup_query(query):
        wants_rx, wants_dx = False, True

    return rx_filters, dx_filters, wants_rx, wants_dx


def update_context_after_turn(
    ctx: SessionContext,
    rx_filters: Dict[str, Any],
    dx_filters: Dict[str, Any],
    hits: List[Hit],
) -> SessionContext:
    rx_drugs: List[str] = []
    dx_titles: List[str] = []

    if "drug" in rx_filters:
        rx_drugs = [str(rx_filters["drug"])]
    elif "drug_any" in rx_filters:
        rx_drugs = [str(x) for x in rx_filters["drug_any"]][:3]

    if "doc_title" in dx_filters:
        dx_titles = [str(dx_filters["doc_title"])]
    elif "doc_title_any" in dx_filters:
        dx_titles = [str(x) for x in dx_filters["doc_title_any"]][:3]

    if not rx_drugs:
        for h in hits:
            if h.source_type != "RX":
                continue
            drug = str((getattr(h.doc, "meta", {}) or {}).get("drug", "")).strip()
            if drug and drug not in rx_drugs:
                rx_drugs.append(drug)
            if len(rx_drugs) >= 3:
                break

    if not dx_titles:
        for h in hits:
            if h.source_type != "DX":
                continue
            title = str((getattr(h.doc, "meta", {}) or {}).get("doc_title", "")).strip()
            if title and title not in dx_titles:
                dx_titles.append(title)
            if len(dx_titles) >= 3:
                break

    rx_count = sum(1 for h in hits[:6] if h.source_type == "RX")
    dx_count = sum(1 for h in hits[:6] if h.source_type == "DX")
    if rx_count > 0 and dx_count == 0:
        pref = "RX"
    elif dx_count > 0 and rx_count == 0:
        pref = "DX"
    elif rx_count > dx_count:
        pref = "RX"
    elif dx_count > rx_count:
        pref = "DX"
    else:
        pref = "BOTH"

    return SessionContext(
        last_rx_drugs=rx_drugs or ctx.last_rx_drugs,
        last_dx_titles=dx_titles or ctx.last_dx_titles,
        preferred_domain=pref,
    )


def build_sources_text(hits: List[Hit]) -> str:
    blocks: List[str] = []
    for i, h in enumerate(hits, start=1):
        blocks.append(
            f"SOURCE {i}\n"
            f"type: {h.source_type}\n"
            f"doc_id: {getattr(h.doc, 'doc_id', '')}\n"
            f"meta: {getattr(h.doc, 'meta', {})}\n"
            f"text:\n{getattr(h.doc, 'text', '')}\n"
        )
    return "\n---\n".join(blocks)


def azure_chat(cfg: Dict[str, str], messages: List[Dict[str, str]], temperature: float = 0.1) -> str:
    url = (
        f"{cfg['AZURE_ENDPOINT']}/openai/deployments/{cfg['AZURE_DEPLOYMENT']}"
        f"/chat/completions?api-version={cfg['AZURE_API_VERSION']}"
    )
    headers = {
        "Content-Type": "application/json",
        "api-key": cfg["AZURE_API_KEY"],
    }
    payload = {"messages": messages, "temperature": temperature}

    for attempt in range(4):
        r = requests.post(url, headers=headers, data=json.dumps(payload), timeout=90)
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        if r.status_code == 429 and attempt < 3:
            retry_s = 20
            m = re.search(r"retry after\s+(\d+)\s+seconds", r.text, flags=re.I)
            if m:
                retry_s = max(1, int(m.group(1)))
            time.sleep(retry_s + 1)
            continue
        raise RuntimeError(f"Azure call failed ({r.status_code}): {r.text}")

    raise RuntimeError("Azure call failed after retries.")


def answer_with_llm(cfg: Dict[str, str], question: str, hits: List[Hit]) -> str:
    system_prompt = (
        "You are an RX/DX Q&A assistant.\n"
        "Use only supplied SOURCE blocks.\n"
        "If answer is not in sources, reply exactly: Not in the data provided.\n"
        "Be factual and cite claims as [SOURCE n].\n"
        "When asked for costs by network/state, list all matching rows present in sources.\n"
    )
    user_prompt = (
        f"<question>\n{question}\n</question>\n\n"
        f"<sources>\n{build_sources_text(hits)}\n</sources>"
    )
    return azure_chat(
        cfg,
        [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )


def get_config() -> Dict[str, str]:
    dotenv = load_dotenv_file(PROJECT_ROOT / ".env")
    cfg = {
        "RX_INDEX_DIR": os.getenv("RX_INDEX_DIR", str(PROJECT_ROOT / "rx_index")),
        "DX_INDEX_DIR": os.getenv("DX_INDEX_DIR", str(PROJECT_ROOT / "dx_index")),
        "PREFERRED_EMBED_MODEL": os.getenv("PREFERRED_EMBED_MODEL", "all-MiniLM-L6-v2"),
        "AZURE_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT", dotenv.get("AZURE_OPENAI_ENDPOINT", "")),
        "AZURE_API_KEY": os.getenv("AZURE_OPENAI_API_KEY", dotenv.get("AZURE_OPENAI_API_KEY", "")),
        "AZURE_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION", dotenv.get("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")),
        "AZURE_DEPLOYMENT": os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", dotenv.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4.1")),
    }
    missing = [k for k in ["AZURE_ENDPOINT", "AZURE_API_KEY"] if not cfg[k]]
    if missing:
        raise RuntimeError(f"Missing Azure settings: {', '.join(missing)}")
    return cfg


def main() -> None:
    cfg = get_config()

    print("Loading RX index...")
    rx_index, rx_docs, rx_model, rx_model_name = load_index_bundle(
        cfg["RX_INDEX_DIR"], "rx", cfg["PREFERRED_EMBED_MODEL"]
    )
    rx_drug_names = sorted(set((d.meta or {}).get("drug", "") for d in rx_docs if (d.meta or {}).get("drug")))

    print("Loading DX index...")
    dx_index, dx_docs, dx_model, dx_model_name = load_index_bundle(
        cfg["DX_INDEX_DIR"], "dx", cfg["PREFERRED_EMBED_MODEL"]
    )
    dx_names = sorted(set((d.meta or {}).get("doc_title", "") for d in dx_docs if (d.meta or {}).get("doc_title")))

    print(
        f"[OK] Combined RX+DX ready\n"
        f"  RX chunks={len(rx_docs)} dim={rx_index.d} model={rx_model_name}\n"
        f"  DX chunks={len(dx_docs)} dim={dx_index.d} model={dx_model_name}\n"
    )
    context = SessionContext(last_rx_drugs=[], last_dx_titles=[], preferred_domain="BOTH")

    while True:
        q = input("Ask RX+DX: ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        rx_filters = detect_rx_filters(q, rx_drug_names)
        dx_filters = detect_dx_filters(q, dx_names)

        wants_rx = looks_rx_query(q, rx_drug_names)
        wants_dx = looks_dx_query(q, dx_names)
        if not wants_rx and not wants_dx:
            wants_rx = True
            wants_dx = True
        rx_filters, dx_filters, wants_rx, wants_dx = apply_context_if_needed(
            q, rx_filters, dx_filters, wants_rx, wants_dx, context
        )

        hits: List[Hit] = []
        if wants_rx:
            rx_has_entity_filter = ("drug" in rx_filters) or ("drug_any" in rx_filters)
            rx_hits = retrieve_from_index(
                query=q,
                source_type="RX",
                index=rx_index,
                docs=rx_docs,
                model=rx_model,
                top_n=140,
                filters=rx_filters,
                match_fn=rx_meta_matches,
                relax_filters_if_empty=not rx_has_entity_filter,
            )
            hits.extend(rx_hits[:12])

        if wants_dx:
            dx_has_entity_filter = ("doc_title" in dx_filters) or ("doc_title_any" in dx_filters)
            dx_hits = retrieve_from_index(
                query=q,
                source_type="DX",
                index=dx_index,
                docs=dx_docs,
                model=dx_model,
                top_n=180,
                filters=dx_filters,
                match_fn=dx_meta_matches,
                relax_filters_if_empty=not dx_has_entity_filter,
            )
            hits.extend(dx_hits[:12])

        hits.sort(key=lambda h: h.score, reverse=True)
        top_hits = hits[:10]
        context = update_context_after_turn(context, rx_filters, dx_filters, top_hits)

        print(f"\nRX filters: {rx_filters}")
        print(f"DX filters: {dx_filters}\n")

        if not top_hits:
            print("No matching chunks found.")
            print("\n" + "=" * 80 + "\n")
            continue

        for i, h in enumerate(top_hits[:5], start=1):
            print(
                f"SOURCE {i}: [{h.source_type}] {getattr(h.doc, 'doc_id', '')} "
                f"(score={h.score:.3f}, vec={h.vec_score:.3f}, lex={h.lex_score:.3f})"
            )

        print("\n--- GENERATED ANSWER ---\n")
        answer = answer_with_llm(cfg, q, top_hits)
        print(answer)
        print("\n" + "=" * 80 + "\n")


if __name__ == "__main__":
    main()
