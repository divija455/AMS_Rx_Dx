import os
import pickle
from typing import List, Tuple

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

# Reuse Doc dataclass from step1 file
from rx_builder import Doc


def load_index(index_dir: str) -> Tuple[faiss.Index, List[Doc]]:
    index_path = os.path.join(index_dir, "rx.faiss")
    docs_path = os.path.join(index_dir, "rx_docs.pkl")

    index = faiss.read_index(index_path)
    with open(docs_path, "rb") as f:
        docs = pickle.load(f)

    return index, docs


def retrieve(
    query: str,
    index: faiss.Index,
    docs: List[Doc],
    embed_model_name: str = "BAAI/bge-base-en-v1.5",
    top_k: int = 6,
):
    model = SentenceTransformer(embed_model_name)

    q_emb = model.encode([query], normalize_embeddings=True)
    q_emb = np.asarray(q_emb, dtype="float32")

    scores, idxs = index.search(q_emb, top_k)

    results = []
    for rank in range(top_k):
        i = int(idxs[0][rank])
        results.append((rank + 1, float(scores[0][rank]), docs[i]))
    return results


if __name__ == "__main__":
    INDEX_DIR = "rx_index"   # <-- your output folder from Step 2
    EMBED_MODEL = "BAAI/bge-base-en-v1.5"
    TOP_K = 6

    index, docs = load_index(INDEX_DIR)
    print(f"Loaded index with {len(docs)} chunks.\n")

    while True:
        q = input("List the NDC codes for Avastin ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        results = retrieve(q, index, docs, EMBED_MODEL, TOP_K)

        print("\nTop matches:")
        for rank, score, doc in results:
            print(f"\n#{rank}  score={score:.4f}")
            print("doc_id:", doc.doc_id)
            print("meta  :", doc.meta)
            print("text  :")
            print(doc.text[:800])  # show first 800 chars
        print("\n" + "=" * 80 + "\n")