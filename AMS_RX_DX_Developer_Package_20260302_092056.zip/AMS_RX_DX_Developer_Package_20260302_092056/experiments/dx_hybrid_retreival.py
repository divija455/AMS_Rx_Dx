import math
import os
import pickle
import re
from typing import Any, Dict, List, Tuple
import json

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from dx_builder import Doc

try:
    from rank_bm25 import BM25Okapi  # type: ignore
except Exception:
    BM25Okapi = None

MODEL_BY_DIM = {
    384: "all-MiniLM-L6-v2",
    768: "BAAI/bge-base-en-v1.5",
}


def load_artifacts(index_dir: str) -> Tuple[faiss.Index, List[Doc], List[str]]:
    index_path = os.path.join(index_dir, "dx.faiss")
    docs_path = os.path.join(index_dir, "dx_docs.pkl")

    index = faiss.read_index(index_path)
    with open(docs_path, "rb") as f:
        docs = pickle.load(f)

    diagnosis_names = sorted(set(d.meta.get("doc_title", "") for d in docs if d.meta.get("doc_title")))
    return index, docs, diagnosis_names


def read_index_meta(index_dir: str) -> Dict[str, Any]:
    meta_path = os.path.join(index_dir, "dx_meta.json")
    if not os.path.exists(meta_path):
        return {}
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_compatible_model(
    index: faiss.Index,
    preferred_model: str,
    index_meta: Dict[str, Any],
) -> Tuple[SentenceTransformer, str]:
    candidates: List[str] = []
    for name in [
        preferred_model,
        str(index_meta.get("embedding_model", "")),
        MODEL_BY_DIM.get(index.d, ""),
    ]:
        if name and name not in candidates:
            candidates.append(name)

    for model_name in candidates:
        model = SentenceTransformer(model_name)
        probe = np.asarray(model.encode(["dimension-check"], normalize_embeddings=True), dtype="float32")
        if probe.shape[1] == index.d:
            return model, model_name

    raise RuntimeError(
        f"No compatible embedding model found for index dimension {index.d}. "
        f"Tried: {candidates}. Rebuild the index with your intended model."
    )


def tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", (text or "").lower())


class BM25Lite:
    """Small BM25 fallback when rank_bm25 is unavailable."""

    def __init__(self, corpus_tokens: List[List[str]], k1: float = 1.5, b: float = 0.75):
        self.corpus_tokens = corpus_tokens
        self.k1 = k1
        self.b = b
        self.N = len(corpus_tokens)
        self.doc_lens = np.array([len(toks) for toks in corpus_tokens], dtype=float)
        self.avgdl = float(self.doc_lens.mean()) if self.N else 0.0

        self.df: Dict[str, int] = {}
        self.tfs: List[Dict[str, int]] = []
        for toks in corpus_tokens:
            tf: Dict[str, int] = {}
            for t in toks:
                tf[t] = tf.get(t, 0) + 1
            self.tfs.append(tf)
            for t in tf:
                self.df[t] = self.df.get(t, 0) + 1

        self.idf = {
            t: math.log(1 + (self.N - df + 0.5) / (df + 0.5))
            for t, df in self.df.items()
        }

    def get_scores(self, q_tokens: List[str]) -> np.ndarray:
        if self.N == 0:
            return np.array([], dtype=float)

        q_unique = list(dict.fromkeys(q_tokens))
        scores = np.zeros(self.N, dtype=float)

        for i, tf in enumerate(self.tfs):
            dl = self.doc_lens[i]
            norm = self.k1 * (1 - self.b + self.b * (dl / self.avgdl)) if self.avgdl > 0 else self.k1
            s = 0.0
            for t in q_unique:
                f = tf.get(t, 0)
                if f == 0:
                    continue
                idf = self.idf.get(t, 0.0)
                s += idf * ((f * (self.k1 + 1)) / (f + norm))
            scores[i] = s
        return scores


def build_bm25(docs: List[Doc]):
    corpus_tokens = [tokenize(d.text) for d in docs]
    if BM25Okapi is not None:
        return BM25Okapi(corpus_tokens)
    return BM25Lite(corpus_tokens)


def detect_filters(query: str, diagnosis_names: List[str]) -> Dict[str, Any]:
    q = query.strip().lower()
    filters: Dict[str, Any] = {}

    if any(k in q for k in ["icd10", "icd-10", "icd 10", "icd code", "icd codes"]):
        filters["section_prefix"] = "DX.CodingReferences.ICD10"
    elif "drg" in q:
        filters["section_prefix"] = "DX.CodingReferences.DRG"
    elif "cpt" in q:
        filters["section_prefix"] = "DX.CodingReferences.CPT"
    elif "complication" in q:
        filters["section_prefix"] = "DX.Complications"
    elif "description" in q:
        filters["section_prefix"] = "DX.Description"
    elif any(k in q for k in ["physician comments", "clinical notes"]):
        filters["section_prefix"] = "DX.PhysicianComments"
    elif any(k in q for k in ["treatment analytics", "state costs", "network", "medicare", "cost", "state", "allowed"]):
        filters["section_prefix"] = "DX.TreatmentAnalytics"

    matches = sorted({dn for dn in diagnosis_names if dn.lower() in q}, key=len, reverse=True)
    if len(matches) == 1:
        filters["doc_title"] = matches[0]
    elif len(matches) > 1:
        filters["doc_title_any"] = matches

    code_match = re.search(r"\b([A-TV-Z][0-9][0-9A-Z](?:\.[0-9A-Z]{1,4})?)\b", query.upper())
    if code_match:
        filters["text_contains"] = code_match.group(1)

    cpt_match = re.search(r"\b(\d{5})\b", query)
    if cpt_match and filters.get("section_prefix", "").startswith("DX.CodingReferences.CPT"):
        filters["text_contains"] = cpt_match.group(1)

    drg_match = re.search(r"\b(\d{3})\b", query)
    if drg_match and filters.get("section_prefix", "").startswith("DX.CodingReferences.DRG"):
        filters["text_contains"] = drg_match.group(1)

    return filters


def meta_matches(doc: Doc, filters: Dict[str, Any]) -> bool:
    for k, v in filters.items():
        if k == "section_prefix":
            section = str(doc.meta.get("section", ""))
            if not section.startswith(v):
                return False
        elif k == "doc_title_any":
            if doc.meta.get("doc_title") not in v:
                return False
        elif k == "text_contains":
            if str(v).lower() not in doc.text.lower():
                return False
        elif doc.meta.get(k) != v:
            return False
    return True


def retrieve_hybrid(
    query: str,
    embed_model: SentenceTransformer,
    faiss_index: faiss.Index,
    bm25,
    docs: List[Doc],
    diagnosis_names: List[str],
    top_k: int = 8,
    bm25_k: int = 60,
    vec_k: int = 60,
    alpha: float = 0.55,
):
    filters = detect_filters(query, diagnosis_names)

    q_tokens = tokenize(query)
    bm25_scores = bm25.get_scores(q_tokens)
    bm25_top = np.argsort(bm25_scores)[::-1][:bm25_k]

    q_emb = embed_model.encode([query], normalize_embeddings=True).astype("float32")
    if q_emb.shape[1] != faiss_index.d:
        raise ValueError(
            f"Embedding dimension mismatch: query dim={q_emb.shape[1]}, index dim={faiss_index.d}. "
            "Use the same embedding model that was used to build dx_index."
        )
    vec_scores, vec_idxs = faiss_index.search(q_emb, vec_k)
    vec_idxs = vec_idxs[0]
    vec_scores = vec_scores[0]

    candidates = set(int(i) for i in bm25_top) | set(int(i) for i in vec_idxs)

    bm_vals = np.array([bm25_scores[i] for i in candidates], dtype=float)
    v_map = {int(vec_idxs[i]): float(vec_scores[i]) for i in range(len(vec_idxs))}
    v_vals = np.array([v_map.get(i, 0.0) for i in candidates], dtype=float)

    def norm(arr: np.ndarray) -> np.ndarray:
        if arr.size == 0:
            return arr
        mn, mx = float(arr.min()), float(arr.max())
        if mx - mn < 1e-9:
            return np.zeros_like(arr)
        return (arr - mn) / (mx - mn)

    bm_n = norm(bm_vals)
    v_n = norm(v_vals)

    scored = []
    cand_list = list(candidates)
    for j, idx in enumerate(cand_list):
        doc = docs[idx]
        if filters and not meta_matches(doc, filters):
            continue
        final_score = alpha * bm_n[j] + (1 - alpha) * v_n[j]
        scored.append((final_score, idx, bm25_scores[idx], v_map.get(idx, 0.0)))

    scored.sort(reverse=True, key=lambda x: x[0])
    top = scored[:top_k]

    results = []
    for rank, (final_s, idx, bm_s, v_s) in enumerate(top, start=1):
        results.append((rank, final_s, bm_s, v_s, docs[idx]))
    return results, filters


if __name__ == "__main__":
    INDEX_DIR = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\dx_index"
    EMBED_MODEL_NAME = "all-MiniLM-L6-v2"

    faiss_index, docs, diagnosis_names = load_artifacts(INDEX_DIR)
    index_meta = read_index_meta(INDEX_DIR)
    embed_model, chosen_model = load_compatible_model(faiss_index, EMBED_MODEL_NAME, index_meta)
    bm25 = build_bm25(docs)

    print(
        f"Loaded {len(docs)} DX chunks, {len(diagnosis_names)} diagnoses "
        f"(dim={faiss_index.d}) using embedding model: {chosen_model}. Hybrid retrieval ready.\n"
    )

    while True:
        q = input("Ask DX: ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        results, filters = retrieve_hybrid(
            q,
            embed_model,
            faiss_index,
            bm25,
            docs,
            diagnosis_names,
            top_k=8,
            bm25_k=60,
            vec_k=60,
            alpha=0.55,
        )

        print(f"\nDetected filters: {filters}\n")
        for rank, final_s, bm_s, v_s, doc in results:
            print(f"#{rank} final={final_s:.4f}  bm25={bm_s:.2f}  vec={v_s:.4f}")
            print("doc_id:", doc.doc_id)
            print("meta  :", doc.meta)
            print("text  :")
            print(doc.text[:650])
            print("-" * 80)
        print("\n" + "=" * 80 + "\n")
