import json
import os
import pickle
from typing import Any, Dict, List, Tuple

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from dx_builder import Doc

MODEL_BY_DIM = {
    384: "all-MiniLM-L6-v2",
    768: "BAAI/bge-base-en-v1.5",
}


def load_index(index_dir: str) -> Tuple[faiss.Index, List[Doc]]:
    index_path = os.path.join(index_dir, "dx.faiss")
    docs_path = os.path.join(index_dir, "dx_docs.pkl")

    index = faiss.read_index(index_path)
    with open(docs_path, "rb") as f:
        docs = pickle.load(f)

    return index, docs


def read_index_meta(index_dir: str) -> Dict[str, Any]:
    meta_path = os.path.join(index_dir, "dx_meta.json")
    if not os.path.exists(meta_path):
        return {}
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_compatible_model(
    index: faiss.Index,
    preferred_model: str,
    index_meta: Dict[str, Any],
) -> Tuple[SentenceTransformer, str]:
    candidates: List[str] = []
    for name in [
        preferred_model,
        str(index_meta.get("embedding_model", "")),
        MODEL_BY_DIM.get(index.d, ""),
    ]:
        if name and name not in candidates:
            candidates.append(name)

    for model_name in candidates:
        model = SentenceTransformer(model_name)
        probe = np.asarray(model.encode(["dimension-check"], normalize_embeddings=True), dtype="float32")
        if probe.shape[1] == index.d:
            return model, model_name

    raise RuntimeError(
        f"No compatible embedding model found for index dimension {index.d}. "
        f"Tried: {candidates}. Rebuild the index with your intended model."
    )


def retrieve(
    query: str,
    index: faiss.Index,
    docs: List[Doc],
    embed_model: Any = "all-MiniLM-L6-v2",
    top_k: int = 6,
):
    model = SentenceTransformer(embed_model) if isinstance(embed_model, str) else embed_model

    q_emb = model.encode([query], normalize_embeddings=True)
    q_emb = np.asarray(q_emb, dtype="float32")
    if q_emb.shape[1] != index.d:
        raise ValueError(
            f"Embedding dimension mismatch: query dim={q_emb.shape[1]}, index dim={index.d}. "
            "Use the same embedding model that was used to build dx_index."
        )

    scores, idxs = index.search(q_emb, top_k)

    results = []
    for rank in range(top_k):
        i = int(idxs[0][rank])
        results.append((rank + 1, float(scores[0][rank]), docs[i]))
    return results


if __name__ == "__main__":
    INDEX_DIR = r"C:\Users\divija.kapuluru\Projects\AMS-Rx-Dx\dx_index"
    EMBED_MODEL = "all-MiniLM-L6-v2"
    TOP_K = 6

    index, docs = load_index(INDEX_DIR)
    index_meta = read_index_meta(INDEX_DIR)
    model, chosen_model = load_compatible_model(index, EMBED_MODEL, index_meta)
    print(
        f"Loaded DX index with {len(docs)} chunks (dim={index.d}) "
        f"using embedding model: {chosen_model}\n"
    )

    while True:
        q = input("Ask DX query: ").strip()
        if q.lower() in {"exit", "quit"}:
            break

        results = retrieve(q, index, docs, model, TOP_K)

        print("\nTop matches:")
        for rank, score, doc in results:
            print(f"\n#{rank} score={score:.4f}")
            print("doc_id:", doc.doc_id)
            print("meta  :", doc.meta)
            print("text  :")
            print(doc.text[:800])
        print("\n" + "=" * 80 + "\n")
